from setuptools import setup, find_packages

setup(name='drawcircles',
      description='draw empty and filled circles with R, N_points',
      url='https://github.com/vivianapezzotta',
      author='Viviana Pezzotta',
      author_email='viviana.pezzotta@unimi.it',
      #license='MIT',
      version='1.0.0',
      packages=find_packages(),
      #install_requires=['numpy', 'matplotlib.pyplot']
      )
