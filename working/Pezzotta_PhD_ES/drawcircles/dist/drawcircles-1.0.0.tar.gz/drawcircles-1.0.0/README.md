# drawcircles


This allows you to draw an empty and a filled circle with a specific radius and a specific number of points.
